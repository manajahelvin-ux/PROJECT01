"""Interface PySide6."""
